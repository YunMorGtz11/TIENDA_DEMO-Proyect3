const products = [

    // ------------------ 10 ELECTRÓNICA ------------------
    {
        id: 1,
        name: "Teclado Mecánico RGB",
        price: 899,
        category: "electronica",
        image: "imagenes/1.jpg"
    },
    {
        id: 2,
        name: "Bocina Bluetooth Portátil",
        price: 699,
        category: "electronica",
        image: "imagenes/2.jpg"
    },
    {
        id: 3,
        name: "Webcam Full HD 1080p",
        price: 499,
        category: "electronica",
        image: "imagenes/3.jpg"
    },
    {
        id: 4,
        name: "Smartwatch Deportivo",
        price: 1299,
        category: "electronica",
        image: "imagenes/4.jpg"
    },
    {
        id: 5,
        name: "Memoria USB 128GB",
        price: 249,
        category: "electronica",
        image: "imagenes/5.jpg"
    },
    {
        id: 6,
        name: "Cargador Inalámbrico Rápido",
        price: 349,
        category: "electronica",
        image: "imagenes/6.jpg"
    },
    {
        id: 7,
        name: "Laptop Ultrabook 14”",
        price: 8999,
        category: "electronica",
        image: "imagenes/7.jpg"
    },
    {
        id: 8,
        name: "Audífonos Over-Ear Pro",
        price: 1599,
        category: "electronica",
        image: "imagenes/8.jpg"
    },
    {
        id: 9,
        name: "Monitor LED 24”",
        price: 1799,
        category: "electronica",
        image: "imagenes/9.jpg"
    },
    {
        id: 10,
        name: "Mouse Gamer RGB",
        price: 399,
        category: "electronica",
        image: "imagenes/10.jpg"
    },

    // ------------------ 10 ROPA ------------------
    {
        id: 11,
        name: "Camisa Casual de Algodón",
        price: 299,
        category: "ropa",
        image: "imagenes/11.jpg"
    },
    {
        id: 12,
        name: "Pantalón Jogger Unisex",
        price: 449,
        category: "ropa",
        image: "imagenes/12.jpg"
    },
    {
        id: 13,
        name: "Gorra Negra Clásica",
        price: 199,
        category: "ropa",
        image: "imagenes/13.jpg"
    },
    {
        id: 14,
        name: "Tenis Deportivos Urbanos",
        price: 749,
        category: "ropa",
        image: "imagenes/14.jpg"
    },
    {
        id: 15,
        name: "Sudadera térmica",
        price: 599,
        category: "ropa",
        image: "imagenes/15.jpg"
    },
    {
        id: 16,
        name: "Shorts Deportivos",
        price: 199,
        category: "ropa",
        image: "imagenes/16.jpg"
    },
    {
        id: 17,
        name: "Chamarra de Invierno",
        price: 999,
        category: "ropa",
        image: "imagenes/17.jpg"
    },
    {
        id: 18,
        name: "Calcetas Premium 3 Pares",
        price: 129,
        category: "ropa",
        image: "imagenes/18.jpg"
    },
    {
        id: 19,
        name: "Playera Oversize Blanca",
        price: 179,
        category: "ropa",
        image: "imagenes/19.jpg"
    },
    {
        id: 20,
        name: "Pants Deportivos",
        price: 399,
        category: "ropa",
        image: "imagenes/20.jpg"
    },

    // ------------------ 10 LIBROS ------------------
    {
        id: 21,
        name: "Guía de Python para Principiantes",
        price: 299,
        category: "libros",
        image: "imagenes/21.jpg"
    },
    {
        id: 22,
        name: "El Arte de la Programación",
        price: 399,
        category: "libros",
        image: "imagenes/22.jpg"
    },
    {
        id: 23,
        name: "Historia Universal Ilustrada",
        price: 499,
        category: "libros",
        image: "imagenes/23.jpg"
    },
    {
        id: 24,
        name: "Manual de Electrónica Básica",
        price: 259,
        category: "libros",
        image: "imagenes/24.jpg"
    },
    {
        id: 25,
        name: "Aprende CSS desde Cero",
        price: 229,
        category: "libros",
        image: "imagenes/25.jpg"
    },
    {
        id: 26,
        name: "Programación con Java Moderno",
        price: 349,
        category: "libros",
        image: "imagenes/26.jpg"
    },
    {
        id: 27,
        name: "Física Básica para Estudiantes",
        price: 279,
        category: "libros",
        image: "imagenes/27.jpg"
    },
    {
        id: 28,
        name: "Cuentos Fantásticos Ilustrados",
        price: 199,
        category: "libros",
        image: "imagenes/28.jpg"
    },
    {
        id: 29,
        name: "Matemáticas para Ingeniería",
        price: 549,
        category: "libros",
        image: "imagenes/29.jpg"
    },
    {
        id: 30,
        name: "Guía para Aprender React",
        price: 299,
        category: "libros",
        image: "imagenes/30.jpg"
    }

];

let cart = [];

const productsContainer = document.getElementById("productsContainer");
const cartPanel = document.getElementById("cartPanel");
const cartBtn = document.getElementById("cartBtn");
const cartItems = document.getElementById("cartItems");
const cartCount = document.getElementById("cartCount");
const subtotal = document.getElementById("subtotal");
const searchInput = document.getElementById("searchInput");
const payBtn = document.getElementById("payBtn");

// ------------------ TOAST ------------------
function showToast(message) {
    const toastContainer = document.getElementById("toastContainer");
    const toast = document.createElement("div");
    toast.classList.add("toast");
    toast.textContent = message;
    toastContainer.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

// ------------------ FUNCIONES ------------------

// Mostrar productos
function displayProducts(list) {
    productsContainer.innerHTML = "";
    list.forEach(p => {
        productsContainer.innerHTML += `
            <div class="product-card">
                <img src="${p.image}">
                <h3>${p.name}</h3>
                <p>$${p.price}.00</p>
                <button class="add-btn" onclick="addToCart(${p.id})">Agregar</button>
            </div>
        `;
    });
}

displayProducts(products);

// Agregar al carrito
function addToCart(id) {
    const product = products.find(p => p.id === id);
    const exists = cart.find(p => p.id === id);
    if (exists) {
        exists.quantity++;
    } else {
        cart.push({ ...product, quantity: 1 });
    }
    updateCart();
    showToast("Producto agregado al carrito 🎉");
}

// Mostrar carrito
function updateCart() {
    cartItems.innerHTML = "";
    let total = 0;

    cart.forEach(item => {
        total += item.price * item.quantity;
        cartItems.innerHTML += `
            <div class="cart-item">
                <img src="${item.image}">
                <div>
                    <h4>${item.name}</h4>
                    <p>$${item.price}.00 c/u</p>

                    <div class="quantity-controls">
                        <button onclick="changeQty(${item.id}, -1)">-</button>
                        <span>${item.quantity}</span>
                        <button onclick="changeQty(${item.id}, 1)">+</button>
                    </div>

                    <button onclick="removeItem(${item.id})" style="margin-top:5px;color:red;background:none;border:none;cursor:pointer;">Quitar</button>
                </div>
            </div>
        `;
    });

    cartCount.textContent = cart.length;
    subtotal.textContent = `$${total}.00`;
}

// Cambiar cantidad
function changeQty(id, change) {
    const item = cart.find(p => p.id === id);
    if (!item) return;
    item.quantity += change;
    if (item.quantity <= 0) {
        cart = cart.filter(p => p.id !== id);
    }
    updateCart();
}

// Quitar producto
function removeItem(id) {
    cart = cart.filter(p => p.id !== id);
    updateCart();
}

// Abrir/cerrar carrito
cartBtn.addEventListener("click", () => {
    cartPanel.classList.toggle("open");
});

// Filtros
document.querySelectorAll(".filter-btn").forEach(btn => {
    btn.addEventListener("click", () => {
        document.querySelector(".filter-btn.active").classList.remove("active");
        btn.classList.add("active");

        const category = btn.dataset.category;
        if (category === "all") {
            displayProducts(products);
        } else {
            displayProducts(products.filter(p => p.category === category));
        }
    });
});

// Buscador
searchInput.addEventListener("input", () => {
    const text = searchInput.value.toLowerCase();
    displayProducts(products.filter(p => p.name.toLowerCase().includes(text)));
});

// Pagar
payBtn.addEventListener("click", () => {
    if (cart.length === 0) {
        showToast("Tu carrito está vacío 😅");
    } else {
        showToast("Compra confirmada! 🎉");
        cart = [];
        updateCart();
        cartPanel.classList.remove("open");
    }
});
