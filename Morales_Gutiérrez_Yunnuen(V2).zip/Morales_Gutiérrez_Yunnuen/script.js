const products = [

    // ------------------ 10 ELECTRÓNICA ------------------
    {
        id: 1,
        name: "Teclado Mecánico RGB",
        price: 899,
        category: "electronica",
        image: "imagenes/1.jpg"
    },
    {
        id: 2,
        name: "Bocina Bluetooth Portátil",
        price: 699,
        category: "electronica",
        image: "imagenes/2.jpg"
    },
    {
        id: 3,
        name: "Webcam Full HD 1080p",
        price: 499,
        category: "electronica",
        image: "imagenes/3.jpg"
    },
    {
        id: 4,
        name: "Smartwatch Deportivo",
        price: 1299,
        category: "electronica",
        image: "imagenes/4.jpg"
    },
    {
        id: 5,
        name: "Memoria USB 128GB",
        price: 249,
        category: "electronica",
        image: "imagenes/5.jpg"
    },
    {
        id: 6,
        name: "Cargador Inalámbrico Rápido",
        price: 349,
        category: "electronica",
        image: "imagenes/6.jpg"
    },
    {
        id: 7,
        name: "Laptop Ultrabook 14”",
        price: 8999,
        category: "electronica",
        image: "imagenes/7.jpg"
    },
    {
        id: 8,
        name: "Audífonos Over-Ear Pro",
        price: 1599,
        category: "electronica",
        image: "imagenes/8.jpg"
    },
    {
        id: 9,
        name: "Monitor LED 24”",
        price: 1799,
        category: "electronica",
        image: "imagenes/9.jpg"
    },
    {
        id: 10,
        name: "Mouse Gamer RGB",
        price: 399,
        category: "electronica",
        image: "imagenes/10.jpg"
    },

    // ------------------ 10 ROPA ------------------
    {
        id: 11,
        name: "Camisa Casual de Algodón",
        price: 299,
        category: "ropa",
        image: "imagenes/11.jpg"
    },
    {
        id: 12,
        name: "Pantalón Jogger Unisex",
        price: 449,
        category: "ropa",
        image: "imagenes/12.jpg"
    },
    {
        id: 13,
        name: "Gorra Negra Clásica",
        price: 199,
        category: "ropa",
        image: "imagenes/13.jpg"
    },
    {
        id: 14,
        name: "Tenis Deportivos Urbanos",
        price: 749,
        category: "ropa",
        image: "imagenes/14.jpg"
    },
    {
        id: 15,
        name: "Sudadera térmica",
        price: 599,
        category: "ropa",
        image: "imagenes/15.jpg"
    },
    {
        id: 16,
        name: "Shorts Deportivos",
        price: 199,
        category: "ropa",
        image: "imagenes/16.jpg"
    },
    {
        id: 17,
        name: "Chamarra de Invierno",
        price: 999,
        category: "ropa",
        image: "imagenes/17.jpg"
    },
    {
        id: 18,
        name: "Calcetas Premium 3 Pares",
        price: 129,
        category: "ropa",
        image: "imagenes/18.jpg"
    },
    {
        id: 19,
        name: "Playera Oversize Blanca",
        price: 179,
        category: "ropa",
        image: "imagenes/19.jpg"
    },
    {
        id: 20,
        name: "Pants Deportivos",
        price: 399,
        category: "ropa",
        image: "imagenes/20.jpg"
    },

    // ------------------ 10 LIBROS ------------------
    {
        id: 21,
        name: "Guía de Python para Principiantes",
        price: 299,
        category: "libros",
        image: "imagenes/21.jpg"
    },
    {
        id: 22,
        name: "El Arte de la Programación",
        price: 399,
        category: "libros",
        image: "imagenes/22.jpg"
    },
    {
        id: 23,
        name: "Historia Universal Ilustrada",
        price: 499,
        category: "libros",
        image: "imagenes/23.jpg"
    },
    {
        id: 24,
        name: "Manual de Electrónica Básica",
        price: 259,
        category: "libros",
        image: "imagenes/24.jpg"
    },
    {
        id: 25,
        name: "Aprende CSS desde Cero",
        price: 229,
        category: "libros",
        image: "imagenes/25.jpg"
    },
    {
        id: 26,
        name: "Programación con Java Moderno",
        price: 349,
        category: "libros",
        image: "imagenes/26.jpg"
    },
    {
        id: 27,
        name: "Física Básica para Estudiantes",
        price: 279,
        category: "libros",
        image: "imagenes/27.jpg"
    },
    {
        id: 28,
        name: "Cuentos Fantásticos Ilustrados",
        price: 199,
        category: "libros",
        image: "imagenes/28.jpg"
    },
    {
        id: 29,
        name: "Matemáticas para Ingeniería",
        price: 549,
        category: "libros",
        image: "imagenes/29.jpg"
    },
    {
        id: 30,
        name: "Guía para Aprender React",
        price: 299,
        category: "libros",
        image: "imagenes/30.jpg"
    }


];

let cart = [];
let currentCategory = "all";
let currentSort = "relevancia";

const productsContainer = document.getElementById("productsContainer");
const cartPanel = document.getElementById("cartPanel");
const cartBtn = document.getElementById("cartBtn");
const closeCartBtn = document.getElementById("closeCart");
const cartItems = document.getElementById("cartItems");
const cartCount = document.getElementById("cartCount");
const subtotal = document.getElementById("subtotal");
const searchInput = document.getElementById("searchInput");

// ------------------ TOAST ------------------
function showToast(msg) {
    const cont = document.getElementById("toastContainer");
    const t = document.createElement("div");
    t.classList.add("toast");
    t.textContent = msg;
    cont.appendChild(t);
    setTimeout(() => t.remove(), 3000);
}

// ------------------ ORDENAMIENTO ------------------
function applySort(list) {
    if (currentSort === "menor")
        return [...list].sort((a, b) => a.price - b.price);

    if (currentSort === "mayor")
        return [...list].sort((a, b) => b.price - a.price);

    return [...list].sort(() => Math.random() - 0.5); // relevancia
}

// ------------------ MOSTRAR PRODUCTOS ------------------
function displayProducts(list) {
    productsContainer.innerHTML = "";
    list.forEach(p => {
        productsContainer.innerHTML += `
        <div class="product-card">
            <img src="${p.image}">
            <h3>${p.name}</h3>
            <p>$${p.price}.00</p>
            <button class="add-btn" onclick="addToCart(${p.id})">Agregar</button>
        </div>`;
    });
}

// Mostrar mezclado al cargar
displayProducts(applySort(products));

// ------------------ CARRITO ------------------
function addToCart(id) {
    const p = products.find(x => x.id === id);
    const f = cart.find(x => x.id === id);

    if (f) f.quantity++;
    else cart.push({ ...p, quantity: 1 });

    updateCart();
    showToast("Producto agregado 🎉");
}

function updateCart() {
    cartItems.innerHTML = "";
    let total = 0;

    cart.forEach(item => {
        total += item.price * item.quantity;
        cartItems.innerHTML += `
        <div class="cart-item">
            <img src="${item.image}">
            <div>
                <h4>${item.name}</h4>
                <p>$${item.price}.00 c/u</p>
                <div class="quantity-controls">
                    <button onclick="changeQty(${item.id}, -1)">-</button>
                    <span>${item.quantity}</span>
                    <button onclick="changeQty(${item.id}, 1)">+</button>
                </div>
                <button onclick="removeItem(${item.id})" style="margin-top:5px;color:red">Quitar</button>
            </div>
        </div>`;
    });

    cartCount.textContent = cart.length;
    subtotal.textContent = `$${total}.00`;
}

function changeQty(id, d) {
    const i = cart.find(p => p.id === id);
    if (!i) return;

    i.quantity += d;
    if (i.quantity <= 0) cart = cart.filter(p => p.id !== id);

    updateCart();
}

function removeItem(id) {
    cart = cart.filter(p => p.id !== id);
    updateCart();
}

cartBtn.addEventListener("click", () => {
    cartPanel.classList.toggle("open");
});

closeCartBtn.addEventListener("click", () => {
    cartPanel.classList.remove("open");
});

// ------------------ FILTROS ------------------
document.querySelectorAll(".filter-btn").forEach(btn => {
    btn.addEventListener("click", () => {
        document.querySelector(".filter-btn.active").classList.remove("active");
        btn.classList.add("active");

        currentCategory = btn.dataset.category;

        let filtered =
            currentCategory === "all"
                ? [...products]
                : products.filter(p => p.category === currentCategory);

        const text = searchInput.value.toLowerCase();
        filtered = filtered.filter(p => p.name.toLowerCase().includes(text));

        displayProducts(applySort(filtered));
    });
});

// ------------------ BUSCADOR ------------------
searchInput.addEventListener("input", () => {
    const txt = searchInput.value.toLowerCase();

    let filtered = products.filter(
        p =>
            p.name.toLowerCase().includes(txt) &&
            (currentCategory === "all" ? true : p.category === currentCategory)
    );

    displayProducts(applySort(filtered));
});

// ------------------ ORDENAMIENTO SELECT ------------------
document.getElementById("sortSelect").addEventListener("change", e => {
    currentSort = e.target.value;

    let filtered =
        currentCategory === "all"
            ? [...products]
            : products.filter(p => p.category === currentCategory);

    const txt = searchInput.value.toLowerCase();
    filtered = filtered.filter(p => p.name.toLowerCase().includes(txt));

    displayProducts(applySort(filtered));
});
