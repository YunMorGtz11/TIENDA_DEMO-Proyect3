/* =====================================================================
   LISTA COMPLETA DE PRODUCTOS (IMÁGENES CORREGIDAS: p.image)
   ===================================================================== */

   const products = [

    // ------------------ 10 ELECTRÓNICA ------------------
    { id: 1, name: "Teclado Mecánico RGB", price: 899, category: "electronica", image: "imagenes/1.jpg" },
    { id: 2, name: "Bocina Bluetooth Portátil", price: 699, category: "electronica", image: "imagenes/2.jpg" },
    { id: 3, name: "Webcam Full HD 1080p", price: 499, category: "electronica", image: "imagenes/3.jpg" },
    { id: 4, name: "Smartwatch Deportivo", price: 1299, category: "electronica", image: "imagenes/4.jpg" },
    { id: 5, name: "Memoria USB 128GB", price: 249, category: "electronica", image: "imagenes/5.jpg" },
    { id: 6, name: "Cargador Inalámbrico Rápido", price: 349, category: "electronica", image: "imagenes/6.jpg" },
    { id: 7, name: "Laptop Ultrabook 14”", price: 8999, category: "electronica", image: "imagenes/7.jpg" },
    { id: 8, name: "Audífonos Over-Ear Pro", price: 1599, category: "electronica", image: "imagenes/8.jpg" },
    { id: 9, name: "Monitor LED 24”", price: 1799, category: "electronica", image: "imagenes/9.jpg" },
    { id: 10, name: "Mouse Gamer RGB", price: 399, category: "electronica", image: "imagenes/10.jpg" },

    // ------------------ 10 ROPA ------------------
    { id: 11, name: "Camisa Casual de Algodón", price: 299, category: "ropa", image: "imagenes/11.jpg" },
    { id: 12, name: "Pantalón Jogger Unisex", price: 449, category: "ropa", image: "imagenes/12.jpg" },
    { id: 13, name: "Gorra Negra Clásica", price: 199, category: "ropa", image: "imagenes/13.jpg" },
    { id: 14, name: "Tenis Deportivos Urbanos", price: 749, category: "ropa", image: "imagenes/14.jpg" },
    { id: 15, name: "Sudadera térmica", price: 599, category: "ropa", image: "imagenes/15.jpg" },
    { id: 16, name: "Shorts Deportivos", price: 199, category: "ropa", image: "imagenes/16.jpg" },
    { id: 17, name: "Chamarra de Invierno", price: 999, category: "ropa", image: "imagenes/17.jpg" },
    { id: 18, name: "Calcetas Premium 3 Pares", price: 129, category: "ropa", image: "imagenes/18.jpg" },
    { id: 19, name: "Playera Oversize Blanca", price: 179, category: "ropa", image: "imagenes/19.jpg" },
    { id: 20, name: "Pants Deportivos", price: 399, category: "ropa", image: "imagenes/20.jpg" },

    // ------------------ 10 LIBROS ------------------
    { id: 21, name: "Guía de Python para Principiantes", price: 299, category: "libros", image: "imagenes/21.jpg" },
    { id: 22, name: "El Arte de la Programación", price: 399, category: "libros", image: "imagenes/22.jpg" },
    { id: 23, name: "Historia Universal Ilustrada", price: 499, category: "libros", image: "imagenes/23.jpg" },
    { id: 24, name: "Manual de Electrónica Básica", price: 259, category: "libros", image: "imagenes/24.jpg" },
    { id: 25, name: "Aprende CSS desde Cero", price: 229, category: "libros", image: "imagenes/25.jpg" },
    { id: 26, name: "Programación con Java Moderno", price: 349, category: "libros", image: "imagenes/26.jpg" },
    { id: 27, name: "Física Básica para Estudiantes", price: 279, category: "libros", image: "imagenes/27.jpg" },
    { id: 28, name: "Cuentos Fantásticos Ilustrados", price: 199, category: "libros", image: "imagenes/28.jpg" },
    { id: 29, name: "Matemáticas para Ingeniería", price: 549, category: "libros", image: "imagenes/29.jpg" },
    { id: 30, name: "Guía para Aprender React", price: 299, category: "libros", image: "imagenes/30.jpg" },

    // ------------------ 10 ACCESORIOS ------------------
    { id: 31, name: "Reloj Clásico Unisex", price: 499, category: "accesorios", image: "imagenes/31.jpg" },
    { id: 32, name: "Pulsera Minimalista Acero", price: 159, category: "accesorios", image: "imagenes/32.jpg" },
    { id: 33, name: "Collar de Plata 925", price: 699, category: "accesorios", image: "imagenes/33.jpg" },
    { id: 34, name: "Lentes de Sol UV400", price: 249, category: "accesorios", image: "imagenes/34.jpg" },
    { id: 35, name: "Mochila Urbana Impermeable", price: 549, category: "accesorios", image: "imagenes/35.jpg" },
    { id: 36, name: "Cartera de Piel Sintética", price: 199, category: "accesorios", image: "imagenes/36.jpg" },
    { id: 37, name: "Gafete Porta ID Premium", price: 129, category: "accesorios", image: "imagenes/37.jpg" },
    { id: 38, name: "Anillo Ajustable Inoxidable", price: 149, category: "accesorios", image: "imagenes/38.jpg" },
    { id: 39, name: "Bolsa Tote Reforzada", price: 179, category: "accesorios", image: "imagenes/39.jpg" },
    { id: 40, name: "Cinturón Unisex Casual", price: 159, category: "accesorios", image: "imagenes/40.jpg" },

    // ------------------ 10 COCINA ------------------
    { id: 41, name: "Sartén Antiadherente 28cm", price: 349, category: "cocina", image: "imagenes/41.jpg" },
    { id: 42, name: "Set de Cuchillos Premium", price: 499, category: "cocina", image: "imagenes/42.jpg" },
    { id: 43, name: "Tabla de Corte de Bambú", price: 189, category: "cocina", image: "imagenes/43.jpg" },
    { id: 44, name: "Olla de Acero Inoxidable", price: 399, category: "cocina", image: "imagenes/44.jpg" },
    { id: 45, name: "Vaso Térmico 600ml", price: 249, category: "cocina", image: "imagenes/45.jpg" },
    { id: 46, name: "Tostador de Pan Doble", price: 499, category: "cocina", image: "imagenes/46.jpg" },
    { id: 47, name: "Batidora Manual 5 Velocidades", price: 329, category: "cocina", image: "imagenes/47.jpg" },
    { id: 48, name: "Juego de Contenedores Herméticos", price: 259, category: "cocina", image: "imagenes/48.jpg" },
    { id: 49, name: "Taza Cerámica Diseño Retro", price: 129, category: "cocina", image: "imagenes/49.jpg" },
    { id: 50, name: "Airfryer 3.5 Litros", price: 1299, category: "cocina", image: "imagenes/50.jpg" },

    // ------------------ 10 HOGAR ------------------
    { id: 51, name: "Almohada Memory Foam", price: 399, category: "hogar", image: "imagenes/51.jpg" },
    { id: 52, name: "Lámpara LED de Escritorio", price: 299, category: "hogar", image: "imagenes/52.jpg" },
    { id: 53, name: "Cortinas Blackout", price: 459, category: "hogar", image: "imagenes/53.jpg" },
    { id: 54, name: "Espejo Decorativo Redondo", price: 349, category: "hogar", image: "imagenes/54.jpg" },
    { id: 55, name: "Difusor de Aroma USB", price: 199, category: "hogar", image: "imagenes/55.jpg" },
    { id: 56, name: "Organizador de Ropa", price: 179, category: "hogar", image: "imagenes/56.jpg" },
    { id: 57, name: "Cobija Suave Microfibra", price: 299, category: "hogar", image: "imagenes/57.jpg" },
    { id: 58, name: "Tapete Decorativo Moderno", price: 349, category: "hogar", image: "imagenes/58.jpg" },
    { id: 59, name: "Reloj de Pared Minimalista", price: 249, category: "hogar", image: "imagenes/59.jpg" },
    { id: 60, name: "Set de Velas Aromáticas", price: 199, category: "hogar", image: "imagenes/60.jpg" },

    // ------------------ 10 MASCOTAS ------------------
    { id: 61, name: "Croquetas Premium para Perro 5kg", price: 499, category: "mascotas", image: "imagenes/61.jpg" },
    { id: 62, name: "Juguete Pelota Indestructible", price: 149, category: "mascotas", image: "imagenes/62.jpg" },
    { id: 63, name: "Cama Acolchonada para Mascotas", price: 399, category: "mascotas", image: "imagenes/63.jpg" },
    { id: 64, name: "Plato Doble Antiderrame", price: 179, category: "mascotas", image: "imagenes/64.jpg" },
    { id: 65, name: "Rascador para Gato Deluxe", price: 499, category: "mascotas", image: "imagenes/65.jpg" },
    { id: 66, name: "Collar Ajustable con Placa", price: 129, category: "mascotas", image: "imagenes/66.jpg" },
    { id: 67, name: "Shampoo para Perros Hipoalergénico", price: 159, category: "mascotas", image: "imagenes/67.jpg" },
    { id: 68, name: "Transportadora de Mascotas", price: 599, category: "mascotas", image: "imagenes/68.jpg" },
    { id: 69, name: "Arena para Gato 6kg", price: 199, category: "mascotas", image: "imagenes/69.jpg" },
    { id: 70, name: "Juguete Interactivo con Plumas", price: 139, category: "mascotas", image: "imagenes/70.jpg" },

    // ------------------ 10 BELLEZA ------------------
    { id: 71, name: "Plancha para Cabello Pro", price: 699, category: "belleza", image: "imagenes/71.jpg" },
    { id: 72, name: "Secadora de Cabello 2000W", price: 499, category: "belleza", image: "imagenes/72.jpg" },
    { id: 73, name: "Kit de Brochas Profesional", price: 299, category: "belleza", image: "imagenes/73.jpg" },
    { id: 74, name: "Paleta de Sombras 18 Colores", price: 249, category: "belleza", image: "imagenes/74.jpg" },
    { id: 75, name: "Rímel Waterproof", price: 129, category: "belleza", image: "imagenes/75.jpg" },
    { id: 76, name: "Labial Mate Larga Duración", price: 119, category: "belleza", image: "imagenes/76.jpg" },
    { id: 77, name: "Crema Capilar Reparadora", price: 159, category: "belleza", image: "imagenes/77.jpg" },
    { id: 78, name: "Risador de Pestañas Premium", price: 99, category: "belleza", image: "imagenes/78.jpg" },
    { id: 79, name: "Espejo con Luz LED", price: 299, category: "belleza", image: "imagenes/79.jpg" },
    { id: 80, name: "Peine Antiestático Profesional", price: 89, category: "belleza", image: "imagenes/80.jpg" },

    // ------------------ 10 SKINCARE ------------------
    { id: 81, name: "Serum de Ácido Hialurónico", price: 249, category: "skincare", image: "imagenes/81.jpg" },
    { id: 82, name: "Crema Hidratante Facial", price: 199, category: "skincare", image: "imagenes/82.jpg" },
    { id: 83, name: "Protector Solar FPS50", price: 219, category: "skincare", image: "imagenes/83.jpg" },
    { id: 84, name: "Tónico Facial Antioxidante", price: 159, category: "skincare", image: "imagenes/84.jpg" },
    { id: 85, name: "Mascarilla de Arcilla Detox", price: 129, category: "skincare", image: "imagenes/85.jpg" },
    { id: 86, name: "Exfoliante Facial Suave", price: 149, category: "skincare", image: "imagenes/86.jpg" },
    { id: 87, name: "Crema Corporal Hidratante", price: 179, category: "skincare", image: "imagenes/87.jpg" },
    { id: 88, name: "Gel Facial Aloe Vera", price: 119, category: "skincare", image: "imagenes/88.jpg" },
    { id: 89, name: "Bálsamo Labial Nutritivo", price: 89, category: "skincare", image: "imagenes/89.jpg" },
    { id: 90, name: "Aceite Facial Regenerador", price: 259, category: "skincare", image: "imagenes/90.jpg" },

];


/* =====================================================================
   VARIABLES GLOBALES
   ===================================================================== */
   let filteredCategory = "all";
   let searchQuery = "";
   let sortOption = "relevancia";
   let cart = [];
   
   /* ELEMENTOS DEL DOM */
   const productsContainer = document.getElementById("productsContainer");
   const searchInput = document.getElementById("searchInput");
   const sortSelect = document.getElementById("sortSelect");
   const cartBtn = document.getElementById("cartBtn");
   const cartPanel = document.getElementById("cartPanel");
   const closeCart = document.getElementById("closeCart");
   const cartItemsContainer = document.getElementById("cartItems");
   const cartCount = document.getElementById("cartCount");
   const subtotalDisplay = document.getElementById("subtotal");
   const toastContainer = document.getElementById("toastContainer");
   const payBtn = document.getElementById("payBtn");
   
   
   /* =====================================================================
      FUNCIONES AUXILIARES
      ===================================================================== */
   
   // Mezcla un array (Fisher-Yates)
   function shuffle(array) {
       let currentIndex = array.length, randomIndex;
   
       while (currentIndex !== 0) {
           randomIndex = Math.floor(Math.random() * currentIndex);
           currentIndex--;
           [array[currentIndex], array[randomIndex]] = [array[randomIndex], array[currentIndex]];
       }
   
       return array;
   }
   
   
   /* =====================================================================
      FUNCION PARA MOSTRAR PRODUCTOS
      ===================================================================== */
   function renderProducts() {
       let list = [...products];
   
       if (filteredCategory !== "all") {
           list = list.filter(p => p.category === filteredCategory);
       } else {
           // Para "Todo", mezclamos los productos para que aparezcan distintos
           list = shuffle(list);
       }
   
       if (searchQuery.trim() !== "") {
           list = list.filter(p =>
               p.name.toLowerCase().includes(searchQuery.toLowerCase())
           );
       }
   
       if (sortOption === "menor") {
           list.sort((a, b) => a.price - b.price);
       } else if (sortOption === "mayor") {
           list.sort((a, b) => b.price - a.price);
       }
   
       productsContainer.innerHTML = "";
   
       if (list.length === 0) {
           productsContainer.innerHTML = `<p>No hay productos que coincidan.</p>`;
           return;
       }
   
       list.forEach(p => {
           const card = document.createElement("div");
           card.classList.add("product-card");
   
           card.innerHTML = `
               <img src="${p.image}">
               <h3>${p.name}</h3>
               <p>$${p.price.toFixed(2)}</p>
               <button class="add-btn" onclick="addToCart(${p.id})">Agregar</button>
           `;
   
           productsContainer.appendChild(card);
       });
   }
   
   
   /* =====================================================================
      FILTRO DE CATEGORÍAS
      ===================================================================== */
   document.querySelectorAll(".filter-btn").forEach(btn => {
       btn.addEventListener("click", () => {
           document.querySelectorAll(".filter-btn").forEach(x => x.classList.remove("active"));
           btn.classList.add("active");
   
           filteredCategory = btn.dataset.category;
           renderProducts();
       });
   });
   
   
   /* =====================================================================
      BUSCADOR
      ===================================================================== */
   searchInput.addEventListener("input", () => {
       searchQuery = searchInput.value;
       renderProducts();
   });
   
   
   /* =====================================================================
      ORDENAR POR
      ===================================================================== */
   sortSelect.addEventListener("change", () => {
       sortOption = sortSelect.value;
       renderProducts();
   });
   
   
   /* =====================================================================
      AGREGAR AL CARRITO
      ===================================================================== */
   function addToCart(id) {
       const product = products.find(p => p.id === id);
       const existing = cart.find(item => item.id === id);
   
       if (existing) {
           existing.qty++;
       } else {
           cart.push({ ...product, qty: 1 });
       }
   
       updateCart();
       showToast("Producto agregado al carrito");
   }
   
   
   /* =====================================================================
      ACTUALIZAR CARRITO
      ===================================================================== */
   function updateCart() {
       cartItemsContainer.innerHTML = "";
       let subtotal = 0;
   
       cart.forEach(item => {
           subtotal += item.price * item.qty;
   
           const div = document.createElement("div");
           div.classList.add("cart-item");
   
           div.innerHTML = `
               <img src="${item.image}">
               <div>
                   <h4>${item.name}</h4>
                   <p>$${item.price.toFixed(2)}</p>
   
                   <div class="quantity-controls">
                       <button onclick="changeQty(${item.id}, -1)">-</button>
                       <span>${item.qty}</span>
                       <button onclick="changeQty(${item.id}, 1)">+</button>
                   </div>
   
                   <button onclick="removeItem(${item.id})" style="margin-top:6px;color:#ff6b6b;background:none;border:none;cursor:pointer;">
                       Eliminar
                   </button>
               </div>
           `;
   
           cartItemsContainer.appendChild(div);
       });
   
       cartCount.textContent = cart.reduce((a, b) => a + b.qty, 0);
       subtotalDisplay.textContent = `$${subtotal.toFixed(2)}`;
   }
   
   
   /* =====================================================================
      CAMBIAR CANTIDAD
      ===================================================================== */
   function changeQty(id, amount) {
       const item = cart.find(i => i.id === id);
   
       if (!item) return;
   
       item.qty += amount;
   
       if (item.qty <= 0) {
           cart = cart.filter(i => i.id !== id);
       }
   
       updateCart();
   }
   
   
   /* =====================================================================
      ELIMINAR ARTÍCULO
      ===================================================================== */
   function removeItem(id) {
       cart = cart.filter(i => i.id !== id);
       updateCart();
       showToast("Producto eliminado");
   }
   
   
   /* =====================================================================
      ABRIR / CERRAR CARRITO
      ===================================================================== */
   cartBtn.addEventListener("click", () => {
       cartPanel.classList.add("open");
   });
   
   closeCart.addEventListener("click", () => {
       cartPanel.classList.remove("open");
   });
   
   
   /* =====================================================================
      TOAST
      ===================================================================== */
   function showToast(msg) {
       const toast = document.createElement("div");
       toast.classList.add("toast");
       toast.textContent = msg;
   
       toastContainer.appendChild(toast);
   
       setTimeout(() => {
           toast.remove();
       }, 2500);
   }
   
   
   /* =====================================================================
      FUNCIONALIDAD PAGAR
      ===================================================================== */
   payBtn.addEventListener("click", () => {
       if (cart.length === 0) {
           showToast("El carrito está vacío");
           return;
       }
   
       const subtotal = cart.reduce((acc, item) => acc + item.price * item.qty, 0);
       showToast(`¡Pago realizado! Subtotal: $${subtotal.toFixed(2)}`);
       cart = [];
       updateCart();
       cartPanel.classList.remove("open");
   });
   
   
   /* =====================================================================
      INICIALIZAR
      ===================================================================== */
   renderProducts();

